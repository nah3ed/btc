<?php  /* E3VQQFJeO3QDBmFcZ6rHMG8HNrTgI6e7 */   include("sec.php"); ?>

<?php include("layout1.php") ?>

		<div id="log" class="container"><br>
			<h3>Stai per cancellare irreversibilimente TUTTI i dati (visite e inserimenti)</h3>
          <br>  <h5>sei sicuro?</h5>
          <form action="cancella.php" method="POST">

<input type="submit" class="btn btn-danger" value="Si cancella tutto " />
          </form>
		</div>

<?php include("layout2.php") ?><?php  ?>