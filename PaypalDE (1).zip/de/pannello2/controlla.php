<?php
//DA COMPLETARE
function controlla(){
 //controlla se ci sono aggiornamenti da fare



}
?>