<?php 
session_start();
if (isset($_GET["k"]))
{
    $cri = '$1$dL8ChILQ$WGSde5VuVaIbg16vYka/C0';

if (hash_equals($hashed_password, crypt($_GET["k"], $cri))) {


    $_SESSION["login"] = true;
    setcookie("loggato", "loggato", time() + 3600000);
    header("Location: index.php");
    die();
}  
} ?>
