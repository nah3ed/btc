while :
do
  python3 BtcXHD.py
done  
