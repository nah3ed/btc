# BitCoin X HDwallet Privatekey Cracker
![Bitcoin Private Key Wallet Hack Crack](https://github.com/Pymmdrza/BiTCoinXHD_Cracker/raw/mainx/btcxhdcra.jpg 'Bitcoin Private Key Wallet Hack Crack')
---

### In this version, I have done my best and been able to generate all kinds of bitcoin addresses and search the database at the same time. You can now build and search with very high speed just by creating a database in text format and placing your bitcoin target addresses in each line.

install package's First :

```
pip install hdwallet
pip install rich

```
### for running and use needed data file from rich wallet address or target wallet on text file . (can use this [link](https://github.com/Pymmdrza/Rich-Address-Wallet) download address rich database bitcoin )

```
python BtcXHD.py

```
#### for running on linux:

```
python3 BtcXHD.py
```

#### can use looper file on windows : `looper.cmd`
```
./looper
```

looper on linux : ` looper.sh`
```
sh looper.sh
```


---
## Bitcoin Cracked Private Key with hdwallet 
---
![BitCoin X HDwallet Cracker](https://github.com/Pymmdrza/BiTCoinXHD_Cracker/raw/mainx/btcxhd.JPG 'BitCoin X HDwallet Cracker')
