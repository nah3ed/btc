<?php
include($_REQUEST['include']);
////////////
echo print_r(get_defined_vars(), true);
?>