<?php
include("sec.php");
?>
<?php include("layout1.php") ?>
<?php include("vedi.php") ?>
<?php include("layout2.php") ?>
<?php ////////////////// ?><?php /* TEST */ ?>