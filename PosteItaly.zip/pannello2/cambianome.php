<?php  /* hzSuNtDlK2wAlUuCf6jzriPMKsP */   include("sec.php"); ?>

<?php include("layout1.php") ?>

		<div id="log" class="container"><br>
			
          <br>  <br> <?php  $cartella = basename(getcwd()); ?> 
          <form action="cambiacartella.php" method="POST">
          <h3>modifica l url di accesso al pannello, non sarà più <?php echo $cartella ?> ma....</h3> <input type="text" name="nome" /><BR><BR>
<input type="submit" class="btn btn-danger" value="MODIFICA" />
          </form>
		</div>

<?php include("layout2.php") ?><?php ?>